"use client";

import { FormEvent, useMemo, useState } from "react";

import {
  CalendarDays,
  CheckCircle2,
  Eye,
  EyeOff,
  Link2,
  LockKeyhole,
  Mail,
  RefreshCw,
  UserRound,
} from "lucide-react";

type Plan = "PREMIUM" | "PREMIUM_PLUS";

function formatDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function addMonthsClamped(
  sourceDate: Date,
  months: number,
) {
  const sourceDay = sourceDate.getDate();

  const target = new Date(sourceDate);

  target.setDate(1);
  target.setMonth(target.getMonth() + months);

  const lastDay = new Date(
    target.getFullYear(),
    target.getMonth() + 1,
    0,
  ).getDate();

  target.setDate(
    Math.min(sourceDay, lastDay),
  );

  return target;
}

export default function CreateUserForm() {
  const today = useMemo(() => new Date(), []);

  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [slug, setSlug] = useState("");

  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] =
    useState(false);

  const [plan, setPlan] =
    useState<Plan>("PREMIUM");

  const [startDate, setStartDate] = useState(
    formatDateInput(today),
  );

  const [expiryDate, setExpiryDate] = useState(
    formatDateInput(
      addMonthsClamped(today, 1),
    ),
  );

  const [autoRenew, setAutoRenew] =
    useState(false);

  const [mustChangePassword, setMustChangePassword] =
    useState(true);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const maxLinks =
    plan === "PREMIUM_PLUS" ? 100 : 40;

  function handleStartDateChange(
    value: string,
  ) {
    setStartDate(value);

    if (!value) {
      return;
    }

    const parsed = new Date(
      `${value}T12:00:00`,
    );

    setExpiryDate(
      formatDateInput(
        addMonthsClamped(parsed, 1),
      ),
    );
  }

  function handleUsernameChange(
    value: string,
  ) {
    const normalized = value
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, "");

    setUsername(normalized);

    /*
      Dok admin nije ručno promenio slug,
      držimo ga sinhronizovanim sa username-om.
    */
    if (
      !slug ||
      slug === username
    ) {
      setSlug(normalized);
    }
  }

  function generatePassword() {
    const characters =
      "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";

    let generated = "";

    for (let i = 0; i < 14; i++) {
      generated +=
        characters[
          Math.floor(
            Math.random() *
              characters.length,
          )
        ];
    }

    setPassword(generated);
    setShowPassword(true);
  }

  function handleSubmit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError("");
    setSuccess(false);

    if (
      !displayName.trim() ||
      !username.trim() ||
      !email.trim() ||
      !slug.trim() ||
      !password.trim()
    ) {
      setError(
        "Please fill in all required fields.",
      );
      return;
    }

    if (password.length < 8) {
      setError(
        "Temporary password must contain at least 8 characters.",
      );
      return;
    }

    if (
      new Date(expiryDate) <=
      new Date(startDate)
    ) {
      setError(
        "Subscription expiry must be after the start date.",
      );
      return;
    }

    /*
      Kasnije:
      POST /api/admin/users

      Za sada samo simulacija.
    */
    setSuccess(true);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="mx-auto max-w-7xl"
    >
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* LEFT */}
        <div className="space-y-6">
          {/* CUSTOMER */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6">
            <div>
              <h2 className="text-lg font-semibold text-zinc-950">
                Customer information
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                Basic information used for the
                customer account and public profile.
              </p>
            </div>

            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <Field
                label="Display name"
                icon={UserRound}
                required
              >
                <input
                  type="text"
                  value={displayName}
                  onChange={(event) =>
                    setDisplayName(
                      event.target.value,
                    )
                  }
                  placeholder="Sky Hook"
                  className="field-input"
                />
              </Field>

              <Field
                label="Login username"
                icon={UserRound}
                required
              >
                <input
                  type="text"
                  value={username}
                  onChange={(event) =>
                    handleUsernameChange(
                      event.target.value,
                    )
                  }
                  placeholder="skyhook"
                  className="field-input"
                />
              </Field>

              <Field
                label="Email address"
                icon={Mail}
                required
                className="sm:col-span-2"
              >
                <input
                  type="email"
                  value={email}
                  onChange={(event) =>
                    setEmail(
                      event.target.value,
                    )
                  }
                  placeholder="contact@example.com"
                  className="field-input"
                />
              </Field>

              <Field
                label="Public slug"
                icon={Link2}
                required
                className="sm:col-span-2"
              >
                <div className="flex overflow-hidden rounded-xl border border-zinc-200 bg-white focus-within:border-zinc-400">
                  <span className="hidden items-center border-r border-zinc-200 bg-zinc-50 px-4 text-sm text-zinc-500 sm:flex">
                    linkzzz.com/
                  </span>

                  <input
                    type="text"
                    value={slug}
                    onChange={(event) =>
                      setSlug(
                        event.target.value
                          .toLowerCase()
                          .replace(
                            /[^a-z0-9_-]/g,
                            "",
                          ),
                      )
                    }
                    placeholder="skyhook"
                    className="min-w-0 flex-1 px-4 py-3 text-sm text-zinc-950 outline-none"
                  />
                </div>

                <p className="mt-2 text-xs text-zinc-400 sm:hidden">
                  Public URL: linkzzz.com/
                  {slug || "username"}
                </p>
              </Field>
            </div>
          </section>

          {/* SECURITY */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6">
            <div>
              <h2 className="text-lg font-semibold text-zinc-950">
                Login & security
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                Create the initial credentials
                that will be provided to the
                customer.
              </p>
            </div>

            <div className="mt-6">
              <label className="text-sm font-medium text-zinc-900">
                Temporary password
              </label>

              <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                <div className="relative flex-1">
                  <LockKeyhole
                    size={17}
                    className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400"
                  />

                  <input
                    type={
                      showPassword
                        ? "text"
                        : "password"
                    }
                    value={password}
                    onChange={(event) =>
                      setPassword(
                        event.target.value,
                      )
                    }
                    className="h-11 w-full rounded-xl border border-zinc-200 bg-white pl-10 pr-12 text-sm text-zinc-950 outline-none transition focus:border-zinc-400"
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowPassword(
                        (current) =>
                          !current,
                      )
                    }
                    className="absolute right-1.5 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-zinc-400 transition hover:bg-zinc-100 hover:text-zinc-700"
                    aria-label="Show or hide password"
                  >
                    {showPassword ? (
                      <EyeOff size={17} />
                    ) : (
                      <Eye size={17} />
                    )}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={generatePassword}
                  className="min-h-11 shrink-0 rounded-xl border border-zinc-200 px-4 text-sm font-semibold text-zinc-700 transition hover:bg-zinc-50"
                >
                  Generate password
                </button>
              </div>

              <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl bg-zinc-50 p-4">
                <input
                  type="checkbox"
                  checked={mustChangePassword}
                  onChange={(event) =>
                    setMustChangePassword(
                      event.target.checked,
                    )
                  }
                  className="mt-0.5 h-4 w-4 accent-zinc-950"
                />

                <div>
                  <p className="text-sm font-semibold text-zinc-800">
                    Require password change
                  </p>

                  <p className="mt-1 text-xs leading-5 text-zinc-500">
                    Customer must create a new
                    password after their first
                    successful login.
                  </p>
                </div>
              </label>
            </div>
          </section>

          {/* PLAN */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6">
            <h2 className="text-lg font-semibold text-zinc-950">
              Plan
            </h2>

            <p className="mt-1 text-sm text-zinc-500">
              Assign the customer&apos;s initial
              Linkzzz package.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <PlanCard
                title="Premium"
                description="Up to 40 links"
                selected={
                  plan === "PREMIUM"
                }
                onClick={() =>
                  setPlan("PREMIUM")
                }
              />

              <PlanCard
                title="Premium Plus"
                description="Up to 100 links"
                selected={
                  plan ===
                  "PREMIUM_PLUS"
                }
                onClick={() =>
                  setPlan(
                    "PREMIUM_PLUS",
                  )
                }
              />
            </div>
          </section>

          {/* SUBSCRIPTION */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6">
            <div>
              <h2 className="text-lg font-semibold text-zinc-950">
                Subscription
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                Define the initial paid service
                period.
              </p>
            </div>

            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <Field
                label="Start date"
                icon={CalendarDays}
              >
                <input
                  type="date"
                  value={startDate}
                  onChange={(event) =>
                    handleStartDateChange(
                      event.target.value,
                    )
                  }
                  className="field-input"
                />
              </Field>

              <Field
                label="Expiry date"
                icon={CalendarDays}
              >
                <input
                  type="date"
                  value={expiryDate}
                  onChange={(event) =>
                    setExpiryDate(
                      event.target.value,
                    )
                  }
                  className="field-input"
                />
              </Field>
            </div>

            <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl border border-zinc-200 p-4">
              <input
                type="checkbox"
                checked={autoRenew}
                onChange={(event) =>
                  setAutoRenew(
                    event.target.checked,
                  )
                }
                className="mt-0.5 h-4 w-4 accent-zinc-950"
              />

              <div>
                <div className="flex items-center gap-2">
                  <RefreshCw
                    size={15}
                    className="text-zinc-500"
                  />

                  <p className="text-sm font-semibold text-zinc-800">
                    Automatic renewal
                  </p>
                </div>

                <p className="mt-1 text-xs leading-5 text-zinc-500">
                  Automatically extend the
                  subscription by one month when
                  the current period ends.
                </p>
              </div>
            </label>
          </section>

          {/* ERRORS */}
          {error && (
            <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          {success && (
            <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
              <CheckCircle2
                size={19}
                className="mt-0.5 shrink-0 text-emerald-600"
              />

              <div>
                <p className="text-sm font-semibold text-emerald-800">
                  Customer configuration is valid.
                </p>

                <p className="mt-1 text-xs text-emerald-700">
                  Backend creation will be connected
                  when we add PostgreSQL.
                </p>
              </div>
            </div>
          )}

          {/* MOBILE CREATE */}
          <button
            type="submit"
            className="min-h-12 w-full rounded-xl bg-zinc-950 px-5 text-sm font-semibold text-white transition hover:bg-zinc-800 xl:hidden"
          >
            Create customer
          </button>
        </div>

        {/* RIGHT SUMMARY */}
        <aside className="xl:sticky xl:top-28 xl:self-start">
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-zinc-400">
              New customer
            </p>

            <div className="mt-5 flex items-center gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-zinc-950 text-sm font-bold text-white">
                {displayName
                  ? displayName
                      .split(" ")
                      .map(
                        (part) =>
                          part[0],
                      )
                      .join("")
                      .slice(0, 2)
                      .toUpperCase()
                  : "NC"}
              </div>

              <div className="min-w-0">
                <p className="truncate font-semibold text-zinc-950">
                  {displayName ||
                    "Customer name"}
                </p>

                <p className="truncate text-xs text-zinc-400">
                  @
                  {username ||
                    "username"}
                </p>
              </div>
            </div>

            <div className="mt-6 space-y-4 border-t border-zinc-100 pt-5">
              <SummaryRow
                label="Plan"
                value={
                  plan ===
                  "PREMIUM_PLUS"
                    ? "Premium Plus"
                    : "Premium"
                }
              />

              <SummaryRow
                label="Link limit"
                value={`${maxLinks}`}
              />

              <SummaryRow
                label="Status"
                value="Active"
              />

              <SummaryRow
                label="Auto renewal"
                value={
                  autoRenew
                    ? "ON"
                    : "OFF"
                }
              />

              <SummaryRow
                label="Start"
                value={
                  startDate ||
                  "Not selected"
                }
              />

              <SummaryRow
                label="Expires"
                value={
                  expiryDate ||
                  "Not selected"
                }
              />
            </div>

            <div className="mt-5 rounded-xl bg-zinc-50 p-4">
              <p className="text-xs font-medium text-zinc-400">
                Public profile
              </p>

              <p className="mt-1 break-all text-sm font-semibold text-zinc-800">
                linkzzz.com/
                {slug || "username"}
              </p>
            </div>

            <button
              type="submit"
              className="mt-5 hidden min-h-12 w-full rounded-xl bg-zinc-950 px-5 text-sm font-semibold text-white transition hover:bg-zinc-800 xl:block"
            >
              Create customer
            </button>
          </section>
        </aside>
      </div>

      {/*
        Tailwind helper za sva obična input polja.
        Ovo je lokalni style tag samo dok ne
        napravimo pravi reusable UI input component.
      */}
      <style jsx global>{`
        .field-input {
          margin-top: 0.5rem;
          height: 2.75rem;
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(228 228 231);
          background: white;
          padding-left: 1rem;
          padding-right: 1rem;
          font-size: 0.875rem;
          color: rgb(24 24 27);
          outline: none;
          transition: border-color 150ms;
        }

        .field-input:focus {
          border-color: rgb(161 161 170);
        }
      `}</style>
    </form>
  );
}

function Field({
  label,
  icon: Icon,
  required = false,
  className = "",
  children,
}: {
  label: string;
  icon: React.ElementType;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <div className="flex items-center gap-2">
        <Icon
          size={15}
          className="text-zinc-400"
        />

        <label className="text-sm font-medium text-zinc-900">
          {label}

          {required && (
            <span className="ml-1 text-red-500">
              *
            </span>
          )}
        </label>
      </div>

      {children}
    </div>
  );
}

function PlanCard({
  title,
  description,
  selected,
  onClick,
}: {
  title: string;
  description: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-24 rounded-2xl border p-4 text-left transition ${
        selected
          ? "border-zinc-950 bg-zinc-950 text-white"
          : "border-zinc-200 bg-white hover:border-zinc-400"
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm font-semibold">
          {title}
        </p>

        {selected && (
          <CheckCircle2 size={17} />
        )}
      </div>

      <p
        className={`mt-2 text-xs ${
          selected
            ? "text-zinc-400"
            : "text-zinc-500"
        }`}
      >
        {description}
      </p>
    </button>
  );
}

function SummaryRow({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-5">
      <span className="text-sm text-zinc-500">
        {label}
      </span>

      <span className="text-right text-sm font-semibold text-zinc-900">
        {value}
      </span>
    </div>
  );
}