"use client";

import {
  BarChart3,
  ChevronDown,
  Globe2,
  Monitor,
  MousePointerClick,
  Smartphone,
  TrendingUp,
  Users,
} from "lucide-react";

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const trafficData = [
  { date: "Aug 01", visits: 310, unique: 245, clicks: 121 },
  { date: "Aug 04", visits: 420, unique: 330, clicks: 168 },
  { date: "Aug 07", visits: 390, unique: 305, clicks: 151 },
  { date: "Aug 10", visits: 510, unique: 402, clicks: 205 },
  { date: "Aug 13", visits: 470, unique: 372, clicks: 198 },
  { date: "Aug 16", visits: 620, unique: 488, clicks: 262 },
  { date: "Aug 19", visits: 580, unique: 453, clicks: 241 },
  { date: "Aug 22", visits: 710, unique: 562, clicks: 301 },
  { date: "Aug 25", visits: 680, unique: 540, clicks: 284 },
  { date: "Aug 28", visits: 790, unique: 621, clicks: 347 },
];

const stats = [
  {
    label: "Total visits",
    value: "12,482",
    change: "+18.4%",
    icon: BarChart3,
  },
  {
    label: "Unique visitors",
    value: "8,921",
    change: "+12.7%",
    icon: Users,
  },
  {
    label: "Link clicks",
    value: "4,817",
    change: "+21.3%",
    icon: MousePointerClick,
  },
  {
    label: "CTR",
    value: "38.6%",
    change: "+2.4%",
    icon: TrendingUp,
  },
];

const topLinks = [
  {
    title: "Listen on Spotify",
    clicks: 1482,
    share: 31,
  },
  {
    title: "Instagram",
    clicks: 923,
    share: 19,
  },
  {
    title: "Latest video",
    clicks: 611,
    share: 13,
  },
  {
    title: "Bandcamp",
    clicks: 407,
    share: 8,
  },
];

const countries = [
  { name: "Serbia", flag: "🇷🇸", percentage: 48 },
  { name: "Germany", flag: "🇩🇪", percentage: 17 },
  { name: "Austria", flag: "🇦🇹", percentage: 11 },
  { name: "United Kingdom", flag: "🇬🇧", percentage: 8 },
  { name: "Other", flag: "🌍", percentage: 16 },
];

const trafficSources = [
  { name: "Instagram", percentage: 41 },
  { name: "Direct", percentage: 23 },
  { name: "TikTok", percentage: 18 },
  { name: "Google", percentage: 10 },
  { name: "Other", percentage: 8 },
];

const devices = [
  {
    name: "Mobile",
    percentage: 82,
    icon: Smartphone,
  },
  {
    name: "Desktop",
    percentage: 16,
    icon: Monitor,
  },
  {
    name: "Tablet",
    percentage: 2,
    icon: Monitor,
  },
];

const browsers = [
  { name: "Chrome", percentage: 46 },
  { name: "Safari", percentage: 32 },
  { name: "Firefox", percentage: 11 },
  { name: "Edge", percentage: 7 },
  { name: "Other", percentage: 4 },
];

export default function AnalyticsDashboard() {
  return (
    <div className="space-y-6">
      {/* TOP BAR */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-950">
            Analytics
          </h1>

          <p className="mt-1 text-sm text-zinc-500">
            Understand your audience and profile performance.
          </p>
        </div>

        <button
          type="button"
          className="flex items-center justify-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-sm font-semibold text-zinc-700 transition hover:bg-zinc-50"
        >
          Last 30 days
          <ChevronDown size={16} />
        </button>
      </div>

      {/* KPI */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;

          return (
            <div
              key={stat.label}
              className="rounded-2xl border border-zinc-200 bg-white p-5"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-zinc-500">
                    {stat.label}
                  </p>

                  <p className="mt-2 text-3xl font-bold tracking-tight text-zinc-950">
                    {stat.value}
                  </p>
                </div>

                <div className="rounded-xl bg-zinc-100 p-2.5 text-zinc-700">
                  <Icon size={20} />
                </div>
              </div>

              <div className="mt-4">
                <span className="text-sm font-semibold text-emerald-600">
                  {stat.change}
                </span>

                <span className="ml-2 text-xs text-zinc-400">
                  vs. previous period
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* TRAFFIC CHART */}
      <section className="rounded-2xl border border-zinc-200 bg-white p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-zinc-950">
              Traffic over time
            </h2>

            <p className="mt-1 text-sm text-zinc-500">
              Visits, unique visitors and clicks during the selected period.
            </p>
          </div>

          <div className="flex flex-wrap gap-4 text-xs font-medium text-zinc-500">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-zinc-950" />
              Visits
            </div>

            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-zinc-500" />
              Unique
            </div>

            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-zinc-300" />
              Clicks
            </div>
          </div>
        </div>

        <div className="mt-8 h-[340px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trafficData}>
              <defs>
                <linearGradient
                  id="visitsGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop
                    offset="5%"
                    stopColor="#18181b"
                    stopOpacity={0.18}
                  />
                  <stop
                    offset="95%"
                    stopColor="#18181b"
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>

              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#e4e4e7"
              />

              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: "#a1a1aa",
                  fontSize: 12,
                }}
                dy={10}
              />

              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: "#a1a1aa",
                  fontSize: 12,
                }}
              />

              <Tooltip
                contentStyle={{
                  borderRadius: "12px",
                  border: "1px solid #e4e4e7",
                  boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
                }}
              />

              <Area
                type="monotone"
                dataKey="visits"
                stroke="#18181b"
                strokeWidth={2.5}
                fill="url(#visitsGradient)"
              />

              <Area
                type="monotone"
                dataKey="unique"
                stroke="#71717a"
                strokeWidth={2}
                fill="transparent"
              />

              <Area
                type="monotone"
                dataKey="clicks"
                stroke="#d4d4d8"
                strokeWidth={2}
                fill="transparent"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ROW 2 */}
      <div className="grid gap-6 xl:grid-cols-2">
        {/* TOP LINKS */}
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <div>
            <h2 className="text-lg font-semibold text-zinc-950">
              Top performing links
            </h2>

            <p className="mt-1 text-sm text-zinc-500">
              Links receiving the most clicks.
            </p>
          </div>

          <div className="mt-6 space-y-5">
            {topLinks.map((link, index) => (
              <div key={link.title}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-zinc-100 text-sm font-semibold text-zinc-600">
                      {index + 1}
                    </div>

                    <div>
                      <p className="text-sm font-semibold text-zinc-900">
                        {link.title}
                      </p>

                      <p className="mt-0.5 text-xs text-zinc-400">
                        {link.share}% of all clicks
                      </p>
                    </div>
                  </div>

                  <p className="text-sm font-bold text-zinc-950">
                    {link.clicks.toLocaleString()}
                  </p>
                </div>

                <div className="ml-12 mt-3 h-1.5 overflow-hidden rounded-full bg-zinc-100">
                  <div
                    className="h-full rounded-full bg-zinc-950"
                    style={{
                      width: `${link.share}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* TRAFFIC SOURCES */}
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-zinc-950">
            Traffic sources
          </h2>

          <p className="mt-1 text-sm text-zinc-500">
            Where your visitors are coming from.
          </p>

          <div className="mt-6 space-y-5">
            {trafficSources.map((source) => (
              <div key={source.name}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-zinc-700">
                    {source.name}
                  </span>

                  <span className="text-sm font-semibold text-zinc-950">
                    {source.percentage}%
                  </span>
                </div>

                <div className="mt-2 h-2 overflow-hidden rounded-full bg-zinc-100">
                  <div
                    className="h-full rounded-full bg-zinc-950"
                    style={{
                      width: `${source.percentage}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* ROW 3 */}
      <div className="grid gap-6 xl:grid-cols-3">
        {/* COUNTRIES */}
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-zinc-950">
                Countries
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                Visitor locations.
              </p>
            </div>

            <Globe2 size={20} className="text-zinc-400" />
          </div>

          <div className="mt-6 space-y-4">
            {countries.map((country) => (
              <div
                key={country.name}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <span className="text-lg">
                    {country.flag}
                  </span>

                  <span className="text-sm font-medium text-zinc-700">
                    {country.name}
                  </span>
                </div>

                <span className="text-sm font-semibold text-zinc-950">
                  {country.percentage}%
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* DEVICES */}
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-zinc-950">
            Devices
          </h2>

          <p className="mt-1 text-sm text-zinc-500">
            Devices used to view your profile.
          </p>

          <div className="mt-6 space-y-4">
            {devices.map((device) => {
              const Icon = device.icon;

              return (
                <div
                  key={device.name}
                  className="flex items-center justify-between rounded-xl bg-zinc-50 p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-zinc-600">
                      <Icon size={17} />
                    </div>

                    <span className="text-sm font-medium text-zinc-700">
                      {device.name}
                    </span>
                  </div>

                  <span className="text-sm font-semibold text-zinc-950">
                    {device.percentage}%
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* BROWSERS */}
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-zinc-950">
            Browsers
          </h2>

          <p className="mt-1 text-sm text-zinc-500">
            Most common browsers.
          </p>

          <div className="mt-6 space-y-4">
            {browsers.map((browser) => (
              <div
                key={browser.name}
                className="flex items-center justify-between"
              >
                <span className="text-sm font-medium text-zinc-700">
                  {browser.name}
                </span>

                <span className="text-sm font-semibold text-zinc-950">
                  {browser.percentage}%
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* NOTE */}
      <div className="rounded-2xl border border-zinc-200 bg-zinc-100/70 px-5 py-4">
        <p className="text-xs leading-5 text-zinc-500">
          Geographic and device information is approximate and depends on
          information available from the visitor&apos;s network and browser.
          Known crawlers and preview bots will be filtered from visitor
          analytics where reliably identifiable.
        </p>
      </div>
    </div>
  );
}