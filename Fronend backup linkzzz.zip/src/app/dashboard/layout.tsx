import DashboardShell from "@/components/dashboard/dashboard-shell";

import { ProfileProvider } from "@/features/profile/profile-context";

export default function DashboardLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ProfileProvider>
      <DashboardShell>
        {children}
      </DashboardShell>
    </ProfileProvider>
  );
}