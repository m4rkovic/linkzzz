import AccountDashboard from "@/components/account/account-dashboard";

export default function AccountPage() {
    return (
        <div className="mx-auto w-full min-w-0 max-w-7xl">
            <AccountDashboard />
        </div>
    );
}