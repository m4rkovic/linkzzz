"use client";

import { useRef, useState } from "react";

import { createMockAdminUser, initialAdminHistory } from "@/features/admin/mock-admin-user";
import type {
  AdminHistoryItem,
  AdminPlan,
  AdminProfileStatus,
  AdminUserModel,
} from "@/features/admin/admin-types";
import { addMonthsClamped, formatAdminDate } from "@/features/admin/subscription-rules";

export function useAdminUser(userId: string) {
  const [user, setUser] = useState<AdminUserModel>(() => createMockAdminUser(userId));
  const [history, setHistory] = useState<AdminHistoryItem[]>(initialAdminHistory);
  const nextHistoryId = useRef(3);

  function addHistory(title: string, description: string) {
    const item: AdminHistoryItem = {
      id: nextHistoryId.current++,
      date: formatAdminDate(new Date()),
      title,
      description,
    };

    setHistory((current) => [item, ...current]);
  }

  function renewSubscription(months: number) {
    const now = new Date();
    const restarting = user.subscriptionStatus === "EXPIRED" || user.subscriptionStatus === "STOPPED";
    const newStart = restarting ? now : user.periodStart;
    const baseDate = restarting ? now : user.periodEnd;
    const newEnd = addMonthsClamped(baseDate, months);

    setUser((current) => ({
      ...current,
      periodStart: newStart,
      periodEnd: newEnd,
      subscriptionStatus: "ACTIVE",
      accountStatus: current.accountStatus === "DISABLED" ? "ACTIVE" : current.accountStatus,
    }));

    addHistory(
      `Renewed for ${months} month${months === 1 ? "" : "s"}`,
      restarting
        ? `New subscription period: ${formatAdminDate(newStart)} – ${formatAdminDate(newEnd)}.`
        : `Subscription extended until ${formatAdminDate(newEnd)}.`,
    );
  }

  function stopRenewal() {
    setUser((current) => ({
      ...current,
      autoRenew: false,
      subscriptionStatus: "CANCEL_AT_PERIOD_END",
    }));
    addHistory("Renewal stopped", `Subscription remains active until ${formatAdminDate(user.periodEnd)}.`);
  }

  function resumeRenewal() {
    setUser((current) => ({
      ...current,
      autoRenew: true,
      subscriptionStatus: "ACTIVE",
    }));
    addHistory("Renewal resumed", "Automatic renewal was enabled.");
  }

  function stopImmediately() {
    setUser((current) => ({
      ...current,
      autoRenew: false,
      subscriptionStatus: "STOPPED",
      accountStatus: "DISABLED",
      profileStatus: "DISABLED",
    }));
    addHistory("Subscription stopped immediately", "Customer access and public profile were disabled. Existing data was preserved.");
  }

  function changePlan(plan: AdminPlan) {
    const previous = user.plan;
    if (previous === plan) return;

    setUser((current) => ({ ...current, plan }));
    addHistory(
      "Plan changed",
      `${previous === "PREMIUM_PLUS" ? "Premium Plus" : "Premium"} changed to ${plan === "PREMIUM_PLUS" ? "Premium Plus" : "Premium"}.`,
    );
  }

  function setProfileStatus(profileStatus: AdminProfileStatus) {
    setUser((current) => ({ ...current, profileStatus }));
    addHistory(
      profileStatus === "DISABLED" ? "Public profile disabled" : "Public profile enabled",
      profileStatus === "DISABLED" ? "Profile was hidden from public access." : "Profile was published again.",
    );
  }

  function changeSlug(slug: string) {
    const previous = user.slug;
    if (previous === slug) return;
    setUser((current) => ({ ...current, slug }));
    addHistory("Profile slug changed", `Public URL changed from /${previous} to /${slug}.`);
  }

  function suspendAccount(reason: string) {
    setUser((current) => ({ ...current, accountStatus: "SUSPENDED", profileStatus: "DISABLED" }));
    addHistory("Account suspended", reason || "Customer account was suspended by administrator.");
  }

  function reactivateAccount() {
    setUser((current) => ({ ...current, accountStatus: "ACTIVE" }));
    addHistory("Account reactivated", "Customer access was restored by administrator.");
  }

  function recordPasswordReset() {
    addHistory("Password reset", "A new temporary password was generated and the customer will be required to change it after sign-in.");
  }

  return {
    user,
    history,
    renewSubscription,
    stopRenewal,
    resumeRenewal,
    stopImmediately,
    changePlan,
    setProfileStatus,
    changeSlug,
    suspendAccount,
    reactivateAccount,
    recordPasswordReset,
  };
}
