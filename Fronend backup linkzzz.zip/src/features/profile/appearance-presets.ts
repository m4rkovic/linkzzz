import { defaultAppearance } from "@/config/profile-defaults";
import type { ProfileAppearance } from "@/types/profile";

export type AppearancePreset = {
  id: string;
  name: string;
  description: string;
  apply: () => Partial<ProfileAppearance>;
};

export const APPEARANCE_FONTS = [
  "Inter, Arial, sans-serif",
  "Arial, sans-serif",
  "Georgia, serif",
  "Verdana, sans-serif",
  "Trebuchet MS, sans-serif",
  "Courier New, monospace",
];

export const APPEARANCE_PRESETS: AppearancePreset[] = [
  {
    id: "classic-dark",
    name: "Classic Dark",
    description: "Clean dark Linkzzz buttons.",
    apply: () => ({
      ...defaultAppearance,
      layoutMode: "classic",
      backgroundType: "solid",
      backgroundColor: "#111214",
      primaryTextColor: "#ffffff",
      secondaryTextColor: "#a1a1aa",
      buttonStyle: "glass",
      buttonBackgroundColor: "#18181b",
      buttonTextColor: "#ffffff",
      buttonBorderColor: "#ffffff",
    }),
  },
  {
    id: "classic-light",
    name: "Classic Light",
    description: "Minimal white profile.",
    apply: () => ({
      ...defaultAppearance,
      layoutMode: "classic",
      backgroundType: "solid",
      backgroundColor: "#fafafa",
      primaryTextColor: "#09090b",
      secondaryTextColor: "#71717a",
      buttonStyle: "outline",
      buttonBackgroundColor: "#ffffff",
      buttonTextColor: "#09090b",
      buttonBorderColor: "#d4d4d8",
    }),
  },
  {
    id: "visual-night",
    name: "Visual Night",
    description: "Dark creator-style image cards.",
    apply: () => ({
      ...defaultAppearance,
      layoutMode: "visual",
      backgroundType: "solid",
      backgroundColor: "#050505",
      primaryTextColor: "#ffffff",
      secondaryTextColor: "#a1a1aa",
      hero: {
        ...defaultAppearance.hero!,
        enabled: true,
        height: 350,
        overlayEnabled: true,
        overlayColor: "#000000",
        overlayOpacity: 0.32,
        profilePosition: "over-hero",
        contentPosition: "bottom-center",
        imageFit: "cover",
        imagePosition: "center",
        fullBleed: true,
      },
      identity: {
        ...defaultAppearance.identity!,
        alignment: "center",
        avatarSize: 96,
        avatarShape: "circle",
        socialIconStyle: "plain",
      },
      cards: {
        ...defaultAppearance.cards!,
        defaultLayout: "half",
        borderRadius: 24,
        cardHeight: 230,
        featuredHeight: 370,
        overlayOpacity: 0.38,
        titlePosition: "bottom-center",
        titleSize: 22,
        borderWidth: 0,
        shadow: 2,
        hoverEffect: "lift",
      },
    }),
  },
  {
    id: "visual-editorial",
    name: "Editorial",
    description: "Large type and structured cards.",
    apply: () => ({
      ...defaultAppearance,
      layoutMode: "visual",
      backgroundType: "solid",
      backgroundColor: "#f4f1ea",
      primaryTextColor: "#111111",
      secondaryTextColor: "#5f5b53",
      fontFamily: "Georgia, serif",
      hero: {
        ...defaultAppearance.hero!,
        enabled: true,
        height: 290,
        overlayOpacity: 0.18,
        profilePosition: "below-hero",
        contentPosition: "below",
        imageFit: "cover",
        imagePosition: "center",
        fullBleed: false,
      },
      identity: {
        ...defaultAppearance.identity!,
        alignment: "left",
        avatarShape: "rounded",
        avatarSize: 92,
        nameSize: 34,
        socialIconStyle: "square",
      },
      cards: {
        ...defaultAppearance.cards!,
        defaultLayout: "full",
        borderRadius: 8,
        spacing: 14,
        cardHeight: 250,
        featuredHeight: 400,
        titlePosition: "bottom-left",
        titleSize: 24,
        borderWidth: 0,
        shadow: 1,
        hoverEffect: "none",
      },
    }),
  },
  {
    id: "visual-neon",
    name: "Neon",
    description: "Gradient background with bold cards.",
    apply: () => ({
      ...defaultAppearance,
      layoutMode: "visual",
      backgroundType: "gradient",
      gradientFrom: "#09090b",
      gradientTo: "#21113c",
      primaryTextColor: "#ffffff",
      secondaryTextColor: "#d4d4d8",
      hero: {
        ...defaultAppearance.hero!,
        enabled: true,
        height: 330,
        overlayOpacity: 0.25,
        profilePosition: "over-hero",
        contentPosition: "bottom-center",
        imageFit: "cover",
        imagePosition: "center",
        fullBleed: true,
      },
      identity: {
        ...defaultAppearance.identity!,
        alignment: "center",
        socialIconStyle: "circle",
      },
      cards: {
        ...defaultAppearance.cards!,
        defaultLayout: "half",
        borderRadius: 22,
        borderWidth: 1,
        shadow: 4,
        hoverEffect: "glow",
      },
    }),
  },
];

export function getFontName(value: string) {
  return value.split(",")[0] ?? value;
}
