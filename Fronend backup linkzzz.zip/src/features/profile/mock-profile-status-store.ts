"use client";

import { useSyncExternalStore } from "react";

import type { ProfileStatus } from "@/types/profile";

const STORAGE_KEY = "linkzzz:mock-profile-statuses";
const CHANGE_EVENT = "linkzzz:mock-profile-status-change";

const validStatuses: ProfileStatus[] = [
  "DRAFT",
  "PUBLISHED",
  "DISABLED",
];

export function useMockProfileStatus(
  slug: string,
  fallbackStatus: ProfileStatus,
) {
  return useSyncExternalStore(
    subscribe,
    () => readMockProfileStatus(slug, fallbackStatus),
    () => fallbackStatus,
  );
}

export function setMockProfileStatus(
  slug: string,
  status: ProfileStatus,
) {
  if (typeof window === "undefined") {
    return;
  }

  const statuses = readStoredStatuses();
  statuses[normalizeSlug(slug)] = status;

  window.localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(statuses),
  );

  window.dispatchEvent(new Event(CHANGE_EVENT));
}

function subscribe(callback: () => void) {
  if (typeof window === "undefined") {
    return () => undefined;
  }

  const notify = () => callback();

  window.addEventListener("storage", notify);
  window.addEventListener(CHANGE_EVENT, notify);

  return () => {
    window.removeEventListener("storage", notify);
    window.removeEventListener(CHANGE_EVENT, notify);
  };
}

function readMockProfileStatus(
  slug: string,
  fallbackStatus: ProfileStatus,
): ProfileStatus {
  if (typeof window === "undefined") {
    return fallbackStatus;
  }

  const storedStatus = readStoredStatuses()[normalizeSlug(slug)];

  return isProfileStatus(storedStatus)
    ? storedStatus
    : fallbackStatus;
}

function readStoredStatuses(): Record<string, ProfileStatus> {
  if (typeof window === "undefined") {
    return {};
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);

  if (!raw) {
    return {};
  }

  try {
    const parsed: unknown = JSON.parse(raw);

    if (!parsed || typeof parsed !== "object") {
      return {};
    }

    const result: Record<string, ProfileStatus> = {};

    for (const [slug, status] of Object.entries(parsed)) {
      if (isProfileStatus(status)) {
        result[normalizeSlug(slug)] = status;
      }
    }

    return result;
  } catch {
    return {};
  }
}

function isProfileStatus(value: unknown): value is ProfileStatus {
  return (
    typeof value === "string" &&
    validStatuses.includes(value as ProfileStatus)
  );
}

function normalizeSlug(slug: string) {
  return slug.trim().toLowerCase();
}
