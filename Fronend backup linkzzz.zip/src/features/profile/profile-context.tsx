"use client";

import {
  createContext,
  useContext,
  useState,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from "react";

import { createMockProfileBySlug } from "@/data/mock-profiles";
import { useMockProfileStatus } from "@/features/profile/mock-profile-status-store";

import type { PublicProfileData } from "@/types/profile";

type ProfileContextValue = {
  profile: PublicProfileData;
  setProfile: Dispatch<SetStateAction<PublicProfileData>>;
};

const ProfileContext = createContext<ProfileContextValue | null>(null);

function createInitialProfile(): PublicProfileData {
  const profile = createMockProfileBySlug("skyhook");

  if (!profile) {
    throw new Error("Default mock profile 'skyhook' is missing.");
  }

  return profile;
}

export function ProfileProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [profileState, setProfile] =
    useState<PublicProfileData>(createInitialProfile);

  const persistedStatus = useMockProfileStatus(
    profileState.slug,
    profileState.status,
  );

  const profile =
    persistedStatus === profileState.status
      ? profileState
      : {
          ...profileState,
          status: persistedStatus,
        };

  return (
    <ProfileContext.Provider value={{ profile, setProfile }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const context = useContext(ProfileContext);

  if (!context) {
    throw new Error("useProfile must be used inside ProfileProvider");
  }

  return context;
}
