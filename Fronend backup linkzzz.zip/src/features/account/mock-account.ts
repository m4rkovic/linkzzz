import type { AccountSummary } from "@/features/account/account-types";

export const mockAccount: AccountSummary = {
  displayName: "Sky Hook",
  username: "skyhook",
  email: "contact@skyhook.rs",
  slug: "skyhook",
  plan: "PREMIUM_PLUS",
  subscriptionStatus: "ACTIVE",
  periodLabel: "Aug 29 – Sep 29, 2026",
  expiresLabel: "September 29, 2026",
  autoRenew: true,
  linksUsed: 57,
};

export function getPlanLimit(plan: AccountSummary["plan"]) {
  return plan === "PREMIUM_PLUS" ? 100 : 40;
}
