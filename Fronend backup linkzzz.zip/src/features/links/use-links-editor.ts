"use client";

import { useMemo, useState } from "react";
import type { DragEndEvent } from "@dnd-kit/core";
import { arrayMove } from "@dnd-kit/sortable";
import { useProfile } from "@/features/profile/profile-context";
import type { PublicProfileData, PublicProfileLink } from "@/types/profile";
import type { LinkDraft } from "@/features/links/link-editor-types";
import { MAX_LINKS } from "@/features/links/link-config";
import { applyDraftToLink, createEmptyDraft, createLinkFromDraft, linkToDraft, normalizeDraft, revokeUnsavedImage, validateDraft } from "@/features/links/link-editor-model";

export function useLinksEditor() {
  const { profile, setProfile } = useProfile();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creatingNew, setCreatingNew] = useState(false);
  const [error, setError] = useState("");
  const [draft, setDraft] = useState<LinkDraft>(() => createEmptyDraft(profile.appearance.cards?.defaultLayout ?? "button"));
  const links = profile.links;

  const previewProfile = useMemo<PublicProfileData>(() => {
    if (editingId) {
      return { ...profile, links: profile.links.map((link) => link.id === editingId ? applyDraftToLink(link, draft) : link) };
    }
    if (creatingNew) {
      return { ...profile, links: [...profile.links, createLinkFromDraft("__preview__", draft)] };
    }
    return profile;
  }, [profile, editingId, creatingNew, draft]);

  function updateLinks(updater: (current: PublicProfileLink[]) => PublicProfileLink[]) {
    setProfile((current) => ({ ...current, links: updater(current.links) }));
  }

  function beginCreate() {
    if (links.length >= MAX_LINKS) return;
    setEditingId(null);
    setCreatingNew(true);
    setError("");
    setDraft(createEmptyDraft(profile.appearance.cards?.defaultLayout ?? "button"));
  }

  function beginEdit(link: PublicProfileLink) {
    if (creatingNew || (editingId && editingId !== link.id)) revokeUnsavedImage(draft, editingId, links);
    setCreatingNew(false);
    setEditingId(link.id);
    setError("");
    setDraft(linkToDraft(link, profile));
  }

  function cancelEditor() {
    revokeUnsavedImage(draft, editingId, links);
    setEditingId(null);
    setCreatingNew(false);
    setError("");
  }

  function saveNewLink() {
    const validation = validateDraft(draft);
    if (validation) return setError(validation);
    const normalized = normalizeDraft(draft);
    updateLinks((current) => [...current, createLinkFromDraft(crypto.randomUUID(), normalized)]);
    setCreatingNew(false);
    setError("");
  }

  function saveExistingLink() {
    if (!editingId) return;
    const validation = validateDraft(draft);
    if (validation) return setError(validation);
    const normalized = normalizeDraft(draft);
    const original = links.find((link) => link.id === editingId);
    updateLinks((current) => current.map((link) => link.id === editingId ? applyDraftToLink(link, normalized) : link));
    if (original?.imageUrl?.startsWith("blob:") && original.imageUrl !== normalized.imageUrl) URL.revokeObjectURL(original.imageUrl);
    setEditingId(null);
    setError("");
  }

  function toggleVisibility(id: string) {
    updateLinks((current) => current.map((link) => link.id === id ? { ...link, visible: !link.visible } : link));
  }

  function deleteLink(id: string) {
    if (!window.confirm("Delete this link?")) return;
    const existing = links.find((link) => link.id === id);
    if (existing?.imageUrl?.startsWith("blob:")) URL.revokeObjectURL(existing.imageUrl);
    updateLinks((current) => current.filter((link) => link.id !== id));
    if (editingId === id) setEditingId(null);
  }

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    updateLinks((current) => {
      const oldIndex = current.findIndex((link) => link.id === active.id);
      const newIndex = current.findIndex((link) => link.id === over.id);
      if (oldIndex === -1 || newIndex === -1) return current;
      return arrayMove(current, oldIndex, newIndex);
    });
  }

  return {
    profile,
    links,
    previewProfile,
    editingId,
    creatingNew,
    error,
    draft,
    setDraft,
    usagePercentage: Math.min((links.length / MAX_LINKS) * 100, 100),
    beginCreate,
    beginEdit,
    cancelEditor,
    saveNewLink,
    saveExistingLink,
    toggleVisibility,
    deleteLink,
    handleDragEnd,
  };
}
