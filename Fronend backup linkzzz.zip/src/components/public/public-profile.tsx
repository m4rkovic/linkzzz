"use client";

import { useState } from "react";

import ProfileRenderer from "@/components/public/profile-renderer";
import {
  getMockProfileBySlug,
  mockVisitor,
} from "@/data/mock-profiles";
import { useMockProfileStatus } from "@/features/profile/mock-profile-status-store";

import type { PublicProfileData } from "@/types/profile";

type PublicProfileProps = {
  slug: string;
};

export default function PublicProfile({
  slug,
}: PublicProfileProps) {
  const baseProfile = getMockProfileBySlug(slug);
  const persistedStatus = useMockProfileStatus(
    slug,
    baseProfile?.status ?? "DRAFT",
  );
  const [copied, setCopied] = useState(false);

  if (!baseProfile) {
    return null;
  }

  const profile: PublicProfileData =
    persistedStatus === baseProfile.status
      ? baseProfile
      : {
          ...baseProfile,
          status: persistedStatus,
        };

  function trackLinkClick(linkId: string) {
    console.log("Analytics event:", {
      type: "LINK_CLICK",
      slug: profile.slug,
      linkId,
      country: mockVisitor.countryCode,
    });
  }

  function trackSocialClick(socialId: string) {
    console.log("Analytics event:", {
      type: "SOCIAL_CLICK",
      slug: profile.slug,
      socialId,
      country: mockVisitor.countryCode,
    });
  }

  async function shareProfile() {
    const url = window.location.href;

    if (navigator.share) {
      try {
        await navigator.share({
          title: profile.displayName,
          text: profile.bio,
          url,
        });
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
      }
    }

    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      window.prompt("Copy profile link:", url);
    }
  }

  return (
    <>
      <ProfileRenderer
        profile={profile}
        visitor={mockVisitor}
        mode="public"
        onShare={shareProfile}
        onLinkClick={trackLinkClick}
        onSocialClick={trackSocialClick}
      />

      {copied && (
        <div
          role="status"
          className="fixed bottom-5 left-1/2 z-[100] -translate-x-1/2 rounded-full bg-zinc-950 px-4 py-2 text-sm font-semibold text-white shadow-xl ring-1 ring-white/10"
        >
          Profile link copied
        </div>
      )}
    </>
  );
}
