import { Sparkles } from "lucide-react";
import { AppearanceSection } from "./appearance-section";
import type { AppearancePreset } from "@/features/profile/appearance-presets";

export default function PresetsSection({ presets, onApply }: {
  presets: AppearancePreset[];
  onApply: (preset: AppearancePreset) => void;
}) {
  return (
    <AppearanceSection icon={Sparkles} title="Presets" description="Starting points only. Every setting stays editable.">
      <div className="grid gap-3 sm:grid-cols-2">
        {presets.map((preset) => (
          <button key={preset.id} type="button" onClick={() => onApply(preset)} className="rounded-2xl border border-zinc-200 bg-white p-4 text-left transition hover:border-zinc-400 hover:bg-zinc-50">
            <p className="text-sm font-bold text-zinc-900">{preset.name}</p>
            <p className="mt-1 text-xs leading-5 text-zinc-400">{preset.description}</p>
          </button>
        ))}
      </div>
    </AppearanceSection>
  );
}
