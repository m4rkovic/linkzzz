"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  useRouter,
  useSearchParams,
} from "next/navigation";

import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Clock3,
  RefreshCw,
  Search,
  UserPlus,
  Users,
} from "lucide-react";

type UserStatus =
  | "ACTIVE"
  | "CANCEL_AT_PERIOD_END"
  | "EXPIRED"
  | "STOPPED"
  | "SUSPENDED";

type UserPlan =
  | "PREMIUM"
  | "PREMIUM_PLUS";

type QuickView =
  | "ALL"
  | "EXPIRING"
  | "CANCELLING"
  | "EXPIRED";

type StatusFilter =
  | "ALL"
  | UserStatus;

type PlanFilter =
  | "ALL"
  | UserPlan;

type UserRow = {
  id: number;
  name: string;
  username: string;
  email: string;
  plan: UserPlan;
  status: UserStatus;
  linksUsed: number;
  maxLinks: number;
  expiresAt: string;
  expiryTimestamp: number;
  autoRenew: boolean;
};

const MOCK_TODAY = new Date(
  "2026-08-30T12:00:00",
).getTime();

const initialUsers: UserRow[] = [
  {
    id: 1,
    name: "Sky Hook",
    username: "skyhook",
    email: "contact@skyhook.rs",
    plan: "PREMIUM_PLUS",
    status: "ACTIVE",
    linksUsed: 57,
    maxLinks: 100,
    expiresAt: "Sep 01, 2026",
    expiryTimestamp: new Date(
      "2026-09-01T12:00:00",
    ).getTime(),
    autoRenew: true,
  },
  {
    id: 2,
    name: "Marko Music",
    username: "markomusic",
    email: "marko@example.com",
    plan: "PREMIUM",
    status: "CANCEL_AT_PERIOD_END",
    linksUsed: 34,
    maxLinks: 40,
    expiresAt: "Sep 03, 2026",
    expiryTimestamp: new Date(
      "2026-09-03T12:00:00",
    ).getTime(),
    autoRenew: false,
  },
  {
    id: 3,
    name: "Studio 22",
    username: "studio22",
    email: "hello@studio22.rs",
    plan: "PREMIUM",
    status: "ACTIVE",
    linksUsed: 21,
    maxLinks: 40,
    expiresAt: "Sep 05, 2026",
    expiryTimestamp: new Date(
      "2026-09-05T12:00:00",
    ).getTime(),
    autoRenew: false,
  },
  {
    id: 4,
    name: "Noise Club",
    username: "noiseclub",
    email: "contact@noiseclub.rs",
    plan: "PREMIUM_PLUS",
    status: "EXPIRED",
    linksUsed: 68,
    maxLinks: 100,
    expiresAt: "Aug 21, 2026",
    expiryTimestamp: new Date(
      "2026-08-21T12:00:00",
    ).getTime(),
    autoRenew: false,
  },
  {
    id: 5,
    name: "Miloš Design",
    username: "milosdesign",
    email: "milos@example.com",
    plan: "PREMIUM",
    status: "STOPPED",
    linksUsed: 13,
    maxLinks: 40,
    expiresAt: "Sep 18, 2026",
    expiryTimestamp: new Date(
      "2026-09-18T12:00:00",
    ).getTime(),
    autoRenew: false,
  },
  {
    id: 6,
    name: "North Studio",
    username: "northstudio",
    email: "north@example.com",
    plan: "PREMIUM_PLUS",
    status: "SUSPENDED",
    linksUsed: 89,
    maxLinks: 100,
    expiresAt: "Oct 08, 2026",
    expiryTimestamp: new Date(
      "2026-10-08T12:00:00",
    ).getTime(),
    autoRenew: true,
  },
  {
    id: 7,
    name: "Velvet Room",
    username: "velvetroom",
    email: "hello@velvetroom.rs",
    plan: "PREMIUM_PLUS",
    status: "EXPIRED",
    linksUsed: 44,
    maxLinks: 100,
    expiresAt: "Aug 27, 2026",
    expiryTimestamp: new Date(
      "2026-08-27T12:00:00",
    ).getTime(),
    autoRenew: false,
  },
];

function getDaysRemaining(
  expiryTimestamp: number,
) {
  return Math.ceil(
    (expiryTimestamp - MOCK_TODAY) /
    (1000 * 60 * 60 * 24),
  );
}

function isExpiringSoon(
  user: UserRow,
) {
  const days =
    getDaysRemaining(
      user.expiryTimestamp,
    );

  return (
    user.status === "ACTIVE" &&
    days >= 0 &&
    days <= 7
  );
}

function addOneMonthClamped(
  timestamp: number,
) {
  const source =
    new Date(timestamp);

  const sourceDay =
    source.getDate();

  const target =
    new Date(source);

  target.setDate(1);

  target.setMonth(
    target.getMonth() + 1,
  );

  const lastDay =
    new Date(
      target.getFullYear(),
      target.getMonth() + 1,
      0,
    ).getDate();

  target.setDate(
    Math.min(
      sourceDay,
      lastDay,
    ),
  );

  return target;
}

function formatDate(
  date: Date,
) {
  return new Intl.DateTimeFormat(
    "en-US",
    {
      month: "short",
      day: "2-digit",
      year: "numeric",
    },
  ).format(date);
}

export default function UsersDashboard() {
  const router = useRouter();
  const searchParams =
    useSearchParams();

  const initialView =
    parseQuickView(
      searchParams.get("view"),
    );

  const [
    users,
    setUsers,
  ] = useState(initialUsers);

  const [
    quickView,
    setQuickView,
  ] =
    useState<QuickView>(
      initialView,
    );

  const [
    search,
    setSearch,
  ] = useState("");

  const [
    statusFilter,
    setStatusFilter,
  ] =
    useState<StatusFilter>(
      "ALL",
    );

  const [
    planFilter,
    setPlanFilter,
  ] =
    useState<PlanFilter>(
      "ALL",
    );

  const counts =
    useMemo(() => {
      return {
        total:
          users.length,

        expiring:
          users.filter(
            isExpiringSoon,
          ).length,

        cancelling:
          users.filter(
            (user) =>
              user.status ===
              "CANCEL_AT_PERIOD_END",
          ).length,

        expired:
          users.filter(
            (user) =>
              user.status ===
              "EXPIRED",
          ).length,
      };
    }, [users]);

  const filteredUsers =
    useMemo(() => {
      const normalizedSearch =
        search
          .trim()
          .toLowerCase();

      return users.filter(
        (user) => {
          const matchesSearch =
            !normalizedSearch ||
            user.name
              .toLowerCase()
              .includes(
                normalizedSearch,
              ) ||
            user.username
              .toLowerCase()
              .includes(
                normalizedSearch,
              ) ||
            user.email
              .toLowerCase()
              .includes(
                normalizedSearch,
              );

          const matchesStatus =
            statusFilter ===
            "ALL" ||
            user.status ===
            statusFilter;

          const matchesPlan =
            planFilter === "ALL" ||
            user.plan ===
            planFilter;

          let matchesQuickView =
            true;

          if (
            quickView ===
            "EXPIRING"
          ) {
            matchesQuickView =
              isExpiringSoon(user);
          }

          if (
            quickView ===
            "CANCELLING"
          ) {
            matchesQuickView =
              user.status ===
              "CANCEL_AT_PERIOD_END";
          }

          if (
            quickView ===
            "EXPIRED"
          ) {
            matchesQuickView =
              user.status ===
              "EXPIRED";
          }

          return (
            matchesSearch &&
            matchesStatus &&
            matchesPlan &&
            matchesQuickView
          );
        },
      );
    }, [
      users,
      search,
      statusFilter,
      planFilter,
      quickView,
    ]);

  function changeQuickView(
    nextView: QuickView,
  ) {
    setQuickView(nextView);

    const params =
      new URLSearchParams(
        searchParams.toString(),
      );

    if (
      nextView === "ALL"
    ) {
      params.delete("view");
    } else {
      params.set(
        "view",
        nextView.toLowerCase(),
      );
    }

    const query =
      params.toString();

    router.replace(
      query
        ? `/admin/users?${query}`
        : "/admin/users",
      {
        scroll: false,
      },
    );
  }

  function renewOneMonth(
    id: number,
  ) {
    setUsers(
      (current) =>
        current.map(
          (user) => {
            if (
              user.id !== id
            ) {
              return user;
            }

            const baseTimestamp =
              user.status ===
                "EXPIRED"
                ? MOCK_TODAY
                : user.expiryTimestamp;

            const newExpiry =
              addOneMonthClamped(
                baseTimestamp,
              );

            return {
              ...user,

              status:
                "ACTIVE",

              expiryTimestamp:
                newExpiry.getTime(),

              expiresAt:
                formatDate(
                  newExpiry,
                ),
            };
          },
        ),
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      {/* HEADER */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-zinc-950">
            Users
          </h1>

          <p className="mt-1 text-sm text-zinc-500">
            Manage customer accounts,
            plans and subscriptions.
          </p>
        </div>

        <Link
          href="/admin/users/new"
          className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-zinc-950 px-4 text-sm font-semibold text-white transition hover:bg-zinc-800"
        >
          <UserPlus size={17} />
          Create user
        </Link>
      </div>

      {/* SUMMARY / QUICK FILTERS */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <SummaryCard
          icon={Users}
          label="Total customers"
          value={counts.total}
          description="All accounts"
          active={
            quickView === "ALL"
          }
          onClick={() =>
            changeQuickView(
              "ALL",
            )
          }
        />

        <SummaryCard
          icon={Clock3}
          label="Expiring soon"
          value={
            counts.expiring
          }
          description="Next 7 days"
          active={
            quickView ===
            "EXPIRING"
          }
          onClick={() =>
            changeQuickView(
              "EXPIRING",
            )
          }
        />

        <SummaryCard
          icon={AlertTriangle}
          label="Cancelling"
          value={
            counts.cancelling
          }
          description="Stops at expiry"
          active={
            quickView ===
            "CANCELLING"
          }
          onClick={() =>
            changeQuickView(
              "CANCELLING",
            )
          }
        />

        <SummaryCard
          icon={CalendarDays}
          label="Expired"
          value={counts.expired}
          description="Needs renewal"
          active={
            quickView ===
            "EXPIRED"
          }
          onClick={() =>
            changeQuickView(
              "EXPIRED",
            )
          }
        />
      </div>

      {/* FILTERS */}
      <section className="rounded-2xl border border-zinc-200 bg-white p-4 sm:p-5">
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_220px_220px]">
          {/* SEARCH */}
          <div className="relative">
            <Search
              size={18}
              className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400"
            />

            <input
              type="search"
              value={search}
              onChange={(event) =>
                setSearch(
                  event.target.value,
                )
              }
              placeholder="Search name, username or email..."
              className="h-11 w-full rounded-xl border border-zinc-200 bg-white pl-10 pr-4 text-sm text-zinc-900 outline-none transition placeholder:text-zinc-400 focus:border-zinc-400"
            />
          </div>

          {/* STATUS */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(event) =>
                setStatusFilter(
                  event.target
                    .value as StatusFilter,
                )
              }
              className="h-11 w-full appearance-none rounded-xl border border-zinc-200 bg-white px-4 pr-10 text-sm font-medium text-zinc-700 outline-none transition focus:border-zinc-400"
            >
              <option value="ALL">
                All statuses
              </option>

              <option value="ACTIVE">
                Active
              </option>

              <option value="CANCEL_AT_PERIOD_END">
                Cancelling
              </option>

              <option value="EXPIRED">
                Expired
              </option>

              <option value="STOPPED">
                Stopped
              </option>

              <option value="SUSPENDED">
                Suspended
              </option>
            </select>

            <ChevronDown
              size={16}
              className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400"
            />
          </div>

          {/* PLAN */}
          <div className="relative">
            <select
              value={planFilter}
              onChange={(event) =>
                setPlanFilter(
                  event.target
                    .value as PlanFilter,
                )
              }
              className="h-11 w-full appearance-none rounded-xl border border-zinc-200 bg-white px-4 pr-10 text-sm font-medium text-zinc-700 outline-none transition focus:border-zinc-400"
            >
              <option value="ALL">
                All plans
              </option>

              <option value="PREMIUM">
                Premium
              </option>

              <option value="PREMIUM_PLUS">
                Premium Plus
              </option>
            </select>

            <ChevronDown
              size={16}
              className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400"
            />
          </div>
        </div>
      </section>

      {/* ACTIVE VIEW */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-zinc-500">
          Showing{" "}
          <span className="font-semibold text-zinc-900">
            {
              filteredUsers.length
            }
          </span>{" "}
          customers
        </p>

        {quickView !==
          "ALL" && (
            <button
              type="button"
              onClick={() =>
                changeQuickView(
                  "ALL",
                )
              }
              className="self-start text-sm font-semibold text-zinc-600 transition hover:text-zinc-950"
            >
              Clear quick filter
            </button>
          )}
      </div>

      {/* DESKTOP TABLE */}
      <section className="hidden overflow-hidden rounded-2xl border border-zinc-200 bg-white lg:block">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1120px]">
            <thead>
              <tr className="border-b border-zinc-100 bg-zinc-50 text-left">
                <TableHeading>
                  Customer
                </TableHeading>

                <TableHeading>
                  Plan
                </TableHeading>

                <TableHeading>
                  Status
                </TableHeading>

                <TableHeading>
                  Links
                </TableHeading>

                <TableHeading>
                  Expires
                </TableHeading>

                <TableHeading>
                  Remaining
                </TableHeading>

                <TableHeading>
                  Auto renew
                </TableHeading>

                <th className="px-5 py-3" />
              </tr>
            </thead>

            <tbody>
              {filteredUsers.map(
                (user) => {
                  const days =
                    getDaysRemaining(
                      user.expiryTimestamp,
                    );

                  return (
                    <tr
                      key={user.id}
                      className="border-b border-zinc-100 last:border-b-0 hover:bg-zinc-50/60"
                    >
                      <td className="px-5 py-4">
                        <CustomerIdentity
                          user={user}
                        />
                      </td>

                      <td className="px-5 py-4">
                        <PlanBadge
                          plan={
                            user.plan
                          }
                        />
                      </td>

                      <td className="px-5 py-4">
                        <StatusBadge
                          status={
                            user.status
                          }
                        />
                      </td>

                      <td className="px-5 py-4">
                        <LinkUsage
                          user={user}
                        />
                      </td>

                      <td className="px-5 py-4">
                        <p className="text-sm font-medium text-zinc-700">
                          {
                            user.expiresAt
                          }
                        </p>
                      </td>

                      <td className="px-5 py-4">
                        <RemainingBadge
                          user={user}
                          days={days}
                        />
                      </td>

                      <td className="px-5 py-4">
                        <AutoRenewBadge
                          enabled={
                            user.autoRenew
                          }
                        />
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex items-center justify-end gap-2">
                          {shouldShowRenew(
                            user,
                          ) && (
                              <button
                                type="button"
                                onClick={() =>
                                  renewOneMonth(
                                    user.id,
                                  )
                                }
                                className="flex min-h-10 items-center gap-2 rounded-xl bg-zinc-950 px-3 text-xs font-semibold text-white transition hover:bg-zinc-800"
                              >
                                <RefreshCw
                                  size={14}
                                />
                                +1 month
                              </button>
                            )}

                          <Link
                            href={`/admin/users/${user.id}`}
                            className="flex min-h-10 items-center justify-center rounded-xl border border-zinc-200 px-3 text-xs font-semibold text-zinc-700 transition hover:bg-zinc-50"
                          >
                            Manage
                          </Link>
                        </div>
                      </td>
                    </tr>
                  );
                },
              )}
            </tbody>
          </table>
        </div>

        {filteredUsers.length ===
          0 && <EmptyUsers />}
      </section>

      {/* MOBILE + TABLET */}
      <div className="grid gap-4 lg:hidden">
        {filteredUsers.map(
          (user) => {
            const days =
              getDaysRemaining(
                user.expiryTimestamp,
              );

            return (
              <article
                key={user.id}
                className="rounded-2xl border border-zinc-200 bg-white p-5"
              >
                <CustomerIdentity
                  user={user}
                />

                <div className="mt-4 flex flex-wrap gap-2">
                  <PlanBadge
                    plan={user.plan}
                  />

                  <StatusBadge
                    status={
                      user.status
                    }
                  />

                  <RemainingBadge
                    user={user}
                    days={days}
                  />
                </div>

                <div className="mt-5 grid grid-cols-2 gap-4 border-y border-zinc-100 py-4">
                  <MobileValue
                    label="Expiry"
                    value={
                      user.expiresAt
                    }
                  />

                  <div>
                    <p className="text-xs font-medium text-zinc-400">
                      Auto renewal
                    </p>

                    <div className="mt-1">
                      <AutoRenewBadge
                        enabled={
                          user.autoRenew
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <LinkUsage
                    user={user}
                  />
                </div>

                <div
                  className={`mt-5 grid gap-2 ${shouldShowRenew(
                    user,
                  )
                      ? "sm:grid-cols-2"
                      : ""
                    }`}
                >
                  {shouldShowRenew(
                    user,
                  ) && (
                      <button
                        type="button"
                        onClick={() =>
                          renewOneMonth(
                            user.id,
                          )
                        }
                        className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-zinc-950 px-4 text-sm font-semibold text-white transition hover:bg-zinc-800"
                      >
                        <RefreshCw
                          size={16}
                        />
                        Renew +1 month
                      </button>
                    )}

                  <Link
                    href={`/admin/users/${user.id}`}
                    className={`flex min-h-11 items-center justify-center rounded-xl px-4 text-sm font-semibold transition ${shouldShowRenew(
                      user,
                    )
                        ? "border border-zinc-200 text-zinc-700 hover:bg-zinc-50"
                        : "bg-zinc-950 text-white hover:bg-zinc-800"
                      }`}
                  >
                    Manage customer
                  </Link>
                </div>
              </article>
            );
          },
        )}

        {filteredUsers.length ===
          0 && (
            <section className="rounded-2xl border border-zinc-200 bg-white">
              <EmptyUsers />
            </section>
          )}
      </div>
    </div>
  );
}

function parseQuickView(
  value: string | null,
): QuickView {
  switch (value) {
    case "expiring":
      return "EXPIRING";

    case "cancelling":
      return "CANCELLING";

    case "expired":
      return "EXPIRED";

    default:
      return "ALL";
  }
}

function shouldShowRenew(
  user: UserRow,
) {
  return (
    user.status ===
    "EXPIRED" ||
    user.status ===
    "CANCEL_AT_PERIOD_END" ||
    isExpiringSoon(user)
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
  description,
  active,
  onClick,
}: {
  icon: React.ElementType;
  label: string;
  value: number;
  description: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-2xl border p-4 text-left transition sm:p-5 ${active
          ? "border-zinc-950 bg-zinc-950 text-white"
          : "border-zinc-200 bg-white hover:border-zinc-400"
        }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p
            className={`text-xs font-medium sm:text-sm ${active
                ? "text-zinc-300"
                : "text-zinc-500"
              }`}
          >
            {label}
          </p>

          <p className="mt-2 text-2xl font-bold sm:text-3xl">
            {value}
          </p>
        </div>

        <div
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${active
              ? "bg-zinc-800 text-white"
              : "bg-zinc-100 text-zinc-600"
            }`}
        >
          <Icon size={17} />
        </div>
      </div>

      <p
        className={`mt-3 text-[11px] sm:text-xs ${active
            ? "text-zinc-400"
            : "text-zinc-400"
          }`}
      >
        {description}
      </p>
    </button>
  );
}

function CustomerIdentity({
  user,
}: {
  user: UserRow;
}) {
  const initials =
    user.name
      .split(" ")
      .map(
        (part) =>
          part[0],
      )
      .join("")
      .slice(0, 2)
      .toUpperCase();

  return (
    <div className="flex min-w-0 items-center gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-zinc-950 text-xs font-bold text-white">
        {initials}
      </div>

      <div className="min-w-0">
        <p className="truncate text-sm font-semibold text-zinc-900">
          {user.name}
        </p>

        <p className="mt-0.5 truncate text-xs text-zinc-400">
          @{user.username} ·{" "}
          {user.email}
        </p>
      </div>
    </div>
  );
}

function PlanBadge({
  plan,
}: {
  plan: UserPlan;
}) {
  return (
    <span className="inline-flex rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-semibold text-zinc-700">
      {plan ===
        "PREMIUM_PLUS"
        ? "Premium Plus"
        : "Premium"}
    </span>
  );
}

function StatusBadge({
  status,
}: {
  status: UserStatus;
}) {
  const styles: Record<
    UserStatus,
    string
  > = {
    ACTIVE:
      "bg-emerald-50 text-emerald-700",

    EXPIRED:
      "bg-red-50 text-red-700",

    CANCEL_AT_PERIOD_END:
      "bg-amber-50 text-amber-700",

    STOPPED:
      "bg-red-50 text-red-700",

    SUSPENDED:
      "bg-zinc-200 text-zinc-700",
  };

  const labels: Record<
    UserStatus,
    string
  > = {
    ACTIVE:
      "Active",

    EXPIRED:
      "Expired",

    CANCEL_AT_PERIOD_END:
      "Cancels at expiry",

    STOPPED:
      "Stopped",

    SUSPENDED:
      "Suspended",
  };

  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${styles[status]}`}
    >
      {labels[status]}
    </span>
  );
}

function RemainingBadge({
  user,
  days,
}: {
  user: UserRow;
  days: number;
}) {
  if (
    user.status ===
    "EXPIRED"
  ) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
        Expired
      </span>
    );
  }

  if (
    user.status ===
    "STOPPED"
  ) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
        Stopped
      </span>
    );
  }

  if (
    user.status ===
    "SUSPENDED"
  ) {
    return (
      <span className="inline-flex rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-semibold text-zinc-600">
        Suspended
      </span>
    );
  }

  if (days < 0) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
        Overdue
      </span>
    );
  }

  if (days === 0) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
        Today
      </span>
    );
  }

  if (days <= 2) {
    return (
      <span className="inline-flex rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
        {days} days
      </span>
    );
  }

  if (days <= 7) {
    return (
      <span className="inline-flex rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700">
        {days} days
      </span>
    );
  }

  return (
    <span className="text-xs font-medium text-zinc-400">
      {days} days
    </span>
  );
}

function AutoRenewBadge({
  enabled,
}: {
  enabled: boolean;
}) {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${enabled
          ? "bg-emerald-50 text-emerald-700"
          : "bg-zinc-100 text-zinc-600"
        }`}
    >
      {enabled
        ? "ON"
        : "OFF"}
    </span>
  );
}

function LinkUsage({
  user,
}: {
  user: UserRow;
}) {
  const percentage =
    Math.min(
      (user.linksUsed /
        user.maxLinks) *
      100,
      100,
    );

  return (
    <div className="min-w-32">
      <div className="flex items-center justify-between gap-3">
        <span className="text-sm font-semibold text-zinc-700">
          {user.linksUsed} /{" "}
          {user.maxLinks}
        </span>

        <span className="text-xs text-zinc-400">
          links
        </span>
      </div>

      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-zinc-100">
        <div
          className="h-full rounded-full bg-zinc-950"
          style={{
            width: `${percentage}%`,
          }}
        />
      </div>
    </div>
  );
}

function MobileValue({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <p className="text-xs font-medium text-zinc-400">
        {label}
      </p>

      <p className="mt-1 text-sm font-semibold text-zinc-800">
        {value}
      </p>
    </div>
  );
}

function TableHeading({
  children,
}: {
  children:
  React.ReactNode;
}) {
  return (
    <th className="px-5 py-3 text-xs font-semibold uppercase tracking-wide text-zinc-400">
      {children}
    </th>
  );
}

function EmptyUsers() {
  return (
    <div className="px-6 py-16 text-center">
      <CheckCircle2
        size={24}
        className="mx-auto text-zinc-300"
      />

      <p className="mt-4 text-sm font-semibold text-zinc-800">
        No customers found
      </p>

      <p className="mt-1 text-xs text-zinc-400">
        Try changing the
        current filters.
      </p>
    </div>
  );
}