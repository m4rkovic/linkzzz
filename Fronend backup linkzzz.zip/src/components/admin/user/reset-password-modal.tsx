"use client";

import { useState } from "react";
import { Check, Copy, KeyRound, RefreshCw, X } from "lucide-react";

import { generateTemporaryPassword } from "@/features/admin/temp-password";

export default function ResetPasswordModal({
  open,
  onClose,
  onReset,
}: {
  open: boolean;
  onClose: () => void;
  onReset: () => void;
}) {
  const [password, setPassword] = useState("");
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  function generate() {
    setPassword(generateTemporaryPassword());
    setCopied(false);
  }

  async function copy() {
    if (!password) return;
    await navigator.clipboard.writeText(password);
    setCopied(true);
  }

  function close() {
    setPassword("");
    setCopied(false);
    onClose();
  }

  function finish() {
    if (!password) return;
    onReset();
    close();
  }

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/40 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full rounded-t-3xl bg-white shadow-2xl sm:max-w-lg sm:rounded-3xl" role="dialog" aria-modal="true" aria-labelledby="reset-password-title">
        <div className="flex items-start justify-between gap-4 border-b border-zinc-100 p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-zinc-100 text-zinc-700"><KeyRound size={18} /></div>
            <div>
              <h2 id="reset-password-title" className="text-lg font-semibold text-zinc-950">Reset password</h2>
              <p className="mt-1 text-sm leading-6 text-zinc-500">Generate a temporary password for this customer.</p>
            </div>
          </div>
          <button type="button" onClick={close} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100"><X size={18} /></button>
        </div>

        <div className="space-y-5 p-5 sm:p-6">
          <div className="rounded-2xl bg-amber-50 p-4 text-sm leading-6 text-amber-800">
            Frontend mock mode: this does not change any real credential yet. The server implementation must hash the password, invalidate relevant sessions and require a password change on next login.
          </div>

          {password ? (
            <div>
              <p className="text-sm font-semibold text-zinc-800">Temporary password</p>
              <div className="mt-2 flex min-w-0 items-center gap-2 rounded-xl border border-zinc-200 bg-zinc-50 p-2">
                <code className="min-w-0 flex-1 break-all px-2 text-sm font-semibold text-zinc-950">{password}</code>
                <button type="button" onClick={copy} className="flex h-10 shrink-0 items-center gap-2 rounded-lg bg-white px-3 text-xs font-semibold text-zinc-700 shadow-sm">
                  {copied ? <Check size={15} /> : <Copy size={15} />}
                  {copied ? "Copied" : "Copy"}
                </button>
              </div>
              <button type="button" onClick={generate} className="mt-3 flex min-h-11 items-center gap-2 rounded-xl border border-zinc-200 px-4 text-sm font-semibold text-zinc-700">
                <RefreshCw size={16} /> Generate another
              </button>
            </div>
          ) : (
            <button type="button" onClick={generate} className="flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-zinc-950 px-5 text-sm font-semibold text-white">
              <RefreshCw size={16} /> Generate temporary password
            </button>
          )}

          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button type="button" onClick={close} className="min-h-11 rounded-xl border border-zinc-200 px-4 text-sm font-semibold text-zinc-700">Cancel</button>
            <button type="button" onClick={finish} disabled={!password} className="min-h-11 rounded-xl bg-zinc-950 px-5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40">Confirm reset</button>
          </div>
        </div>
      </div>
    </div>
  );
}
